﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace classmaker
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }
        string classmake = "";
        private void button1_Click(object sender, EventArgs e)
        {
            if(txtclassname.Text.Length!=0 )
            {
                classmake = classmake + "public class " + txtclassname.Text + "{";
                int i = 0;
                string[] datatype=txtdatatype.Text.Split('\n');
                foreach(string s in txtname.Text.Split('\n'))
                {
                    classmake=classmake+"\n public " + datatype[i]+" "+s+"{set;get;}\n";
                    i++;
                }
                classmake = classmake + "}";
                txtresult.Text = classmake;

            }
            else
            {
                MessageBox.Show("Enter class name");
            }
        }
    }
}
