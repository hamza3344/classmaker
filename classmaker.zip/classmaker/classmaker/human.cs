﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace classmaker
{
    public class human
    {
        public string
         name
        { set; get; }

        public string
         weight
        { set; get; }

        public string
         height
        { set; get; }

        public string
         age
        { set; get; }
    }
}
